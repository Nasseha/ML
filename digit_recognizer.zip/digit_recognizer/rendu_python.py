                   
##########################################################################
################Librarie################
import numpy as np
import pandas as pd# charge un package pour le numérique
import matplotlib.pyplot as plt         # charge un package pour les graphiques
from sklearn.datasets import load_digits
import collections, numpy
from matplotlib import style
import seaborn as sns #faire de beau graphique

from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import requests
import json

from pylab import *

#librairies pour la CAH
from matplotlib import pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
import scipy.cluster.hierarchy as sch
import warnings
warnings.simplefilter(action = "ignore", category = FutureWarning)
from time import time
import numpy as np
import matplotlib.pyplot as plt

from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import scale


import itertools

from sklearn.model_selection import train_test_split

#libraries mesures de performances
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score, recall_score


#library classifier

style.use("ggplot")
from sklearn import svm
from sklearn.svm import LinearSVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_classification
from sklearn.metrics import make_scorer, r2_score
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
from sklearn.model_selection import GridSearchCV
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import f1_score
from sklearn.neighbors import KNeighborsClassifier


from sklearn.metrics import confusion_matrix
from timeit import timeit  # charge un package pour des mesures de temps

import json


# Library CNN Tensorflow et keras
#Librairie tensorflow et keras
from keras.datasets import mnist
import tensorflow as tf
import keras as ks
from keras.utils.np_utils import to_categorical
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense, Dropout, Flatten
from keras.layers import Conv2D, MaxPooling2D, MaxPool2D
from keras.layers import AvgPool2D, BatchNormalization, Reshape
from keras.optimizers import Adadelta, RMSprop, Adam
from keras.losses import categorical_crossentropy
from keras.wrappers.scikit_learn import KerasClassifier
from keras import backend as K
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
import sklearn
import tensorflow as tf
from tensorflow import keras
from sklearn import datasets, svm, metrics, model_selection
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV
from collections import defaultdict





#librairie sklearn
import sklearn as sk
from sklearn.model_selection import train_test_split #Tests de validation croisée
from sklearn import metrics #Calculs des taux de prédition
from sklearn.metrics import accuracy_score
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix #Matrice de confusion
from sklearn.preprocessing import LabelEncoder,StandardScaler
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, make_scorer, r2_score
from sklearn.model_selection import cross_val_score, KFold
from sklearn.model_selection import RandomizedSearchCV, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.exceptions import ConvergenceWarning
warnings.filterwarnings("ignore", category=ConvergenceWarning)




################################################################################


# Chargement des données disponible dans le package sklearn
digits = load_digits()
X, y = digits.data, digits.target


#Montre les dimension de la base de données 
print(X.shape)

#Compte les observations pour chaque labels
print(collections.Counter(y))



#Importation de la base Kaggle
url_path_train = 'train.csv'
url_path_test = 'test.csv'

#Reading the data
Xtrain=pd.read_csv(url_path_train)
X1train = Xtrain

Xtest=pd.read_csv(url_path_test)
X1test = Xtest

y1train=X1train['label']
#y1test=X1test['label']

X1train.drop('label',axis=1,inplace=True)


training_images=X1train.to_numpy()
test_images=X1test.to_numpy()

#Indique les differents label et la dimension de la base Xtrain 
print((np.unique(y1train)))
print(training_images.shape)
print(y1train.shape)


#Representation en piechart de la repartion des labels 
print((y1train).value_counts())
plt.pie(
    y1train.value_counts(normalize = True).values,
    labels = y1train.value_counts(normalize = True).index,
)
plt.title("Répartition de la variable à prédire")
plt.show()


#affichage du Nombre de pixels de la base 8*8
print("Nombre de pixels :      {}".format(X.shape[1]))
print("Nombre d'observations : {}".format(X.shape[0]))
print("Nombre de classes :     {}".format(len(np.unique(y)))) 
#nb.unique(y) renvoi un vecteur des labels unique existant
#len() renvoi la taille du vecteur 

# Choix d'une observation quelconques de la base
idx_to_test = 60

#affichage de la ligne en matrice pour 8*8
print("Affichage d'une ligne de la matrice / image:")
print(X[idx_to_test, :])
print("Affichage de la classe / chiffre associé:")
print(y[idx_to_test])


# Utilisation de la fonction imshow pour l'affichage de l'image numéro idx_to_test:
imgplot = plt.imshow(np.reshape(X[idx_to_test, :], (8, 8)))
#la fonction plt.imshow permet d'avoir une sortie 
#d'un graphique pixelise en couleur 
#la fonction "np.reshape" permet de creer une nouvelle forme de 
#la ligne d'observation sans changer les données

#affiche deux plot en verticale dont un 8*8 et 28*28
plt.subplot(211)
imgplot1 = plt.imshow(np.reshape(X[idx_to_test, :], (8, 8)))
plt.subplot(212)
imgplot = plt.imshow(training_images[idx_to_test].reshape(28, 28))


# Amélioration de la visualisation (niveau de gris) et de la légende:
imgplot = plt.imshow(np.reshape(X[idx_to_test, :], (8, 8)),
                     cmap='gray', aspect='equal', interpolation='nearest')

# Attention aux accents: ne pas oublier le u (Unicode) ci-dessous
plt.title(u'Le chiffre numéro %s est un %s' % (idx_to_test, y[idx_to_test]))



#Analyse selon la moyenne, variance et maximum
#Fonction affichage 
def disp_pics(pic_list, taille1, taille2, title=''):
    """" Fonction qui affiche une liste d'image codée en vecteur """""
    fig, axs = plt.subplots(nrows=2, ncols=5, figsize=(12, 4)) #creation d'une matrice de 2*5
    plt.suptitle(title, fontsize=16)
    for i in range(10):
        opt = dict(cmap='gray', aspect='equal', interpolation='nearest')
        axs.flat[i].imshow(pic_list[i].reshape(taille1, taille2), **opt)
        axs.flat[i].set_title("Chiffre: %s" % i) #affiche le titre + le label
    # Contre-balancer l'affichage pas terrible de matplotlib
    plt.tight_layout() #Ajustez automatiquement les paramètres de plot pour donner un remplissage spécifié.
    plt.subplots_adjust(top=0.85) # permet d'ajuster le plot
    
    
# Récupérer les modalités possible prises (Il y en a bien 10!) 
classes_list = np.unique(y).astype(int)
print ("Liste des classes en présence: ", classes_list)



############################# ANALYSE DES DONNEES ############################# 
#BASE 8*8
# Calculer un représentant moyen pour chaque chiffre 
Xi_mean = [np.mean(X[y == cls], axis=0) for cls in classes_list]  #boucle pour chaque valeur dans classes_list   
disp_pics(Xi_mean,8,8, title=(u"Moyennes sur l'ensemble des données"))

# Calculer un représentant variance pour chaque chiffre 
Xi_var = [np.var(X[y == cls], axis=0) for cls in classes_list]      
disp_pics(Xi_var,8,8, title=(u"Variance sur l'ensemble des données"))

# Calculer un représentant max pour chaque chiffre 
Xi_max = [np.max(X[y == cls], axis=0) for cls in classes_list]    
disp_pics(Xi_max,8,8, title=(u"Maximum sur l'ensemble des données"))


#BASE 28*28
# Récupérer les modalités possible prises (Il y en a bien 10!) 
classes_list = np.unique(y1train).astype(int)
print ("Liste des classes en présence: ", classes_list)   

# Calculer un représentant moyen pour chaque chiffre 
Xi_mean = [np.mean(training_images[y1train == cls], axis=0) for cls in classes_list]  #boucle pour chaque valeur dans classes_list    
disp_pics(Xi_mean,28,28, title=(u"Moyennes sur l'ensemble des données"))

# Calculer un représentant variance pour chaque chiffre 
Xi_var = [np.var(training_images[y1train == cls], axis=0) for cls in classes_list]    
disp_pics(Xi_var,28,28, title=(u"Variance sur l'ensemble des données"))

# Calculer un représentant max pour chaque chiffre 
Xi_max = [np.max(training_images[y1train == cls], axis=0) for cls in classes_list]    
disp_pics(Xi_max,28,28, title=(u"Maximum sur l'ensemble des données"))


######Analyse des composantes principales###### 
pca = PCA()
#BASE 8*8
proj = pca.fit_transform(X)
plt.scatter(proj[:, 0], proj[:, 1], c=y, cmap="Paired")
plt.colorbar()

#Valeurs propres et variance expliquée
n = X.shape[0]
p = X.shape[1]
#valeur corrigée
eigval = (n-1)/n*pca.explained_variance_
print(eigval)
#scree plot
plt.subplot(111)
plt.plot(numpy.arange(1,p+1),eigval) 
plt.title("Scree plot") 
plt.ylabel("Eigen values")
plt.xlabel("Factor number") 
plt.show()
plt.subplot(211)
#cumul de variance expliquée
plt.plot(numpy.arange(1,p+1),numpy.cumsum(pca.explained_variance_ratio_)) 
plt.title("Explained variance vs. # of factors")
plt.ylabel("Cumsum explained variance ratio")
plt.xlabel("Factor number")
plt.show()

#BASE 28*28
pca = PCA(n_components=2)
proj = pca.fit_transform(X1train)
plt.scatter(proj[:, 0], proj[:, 1], c=y1train, cmap="Paired")
plt.colorbar()

###### Analyse non supervisee par CAH ###### 
#générer la matrice des liens 
Z = linkage(X,method='ward',metric='euclidean') 

#génération et affichage du dendrogramme
plt.figure(figsize=(20,12))
plt.title("CAH") 
dendrogram(Z)
plt.show()

########################################
#Classification par k-means
np.random.seed(42)

X_digits = X
y_digits = y
data = scale(X_digits)

n_samples, n_features = data.shape
n_digits = len(np.unique(y_digits))
labels = y_digits

sample_size = 300

print("n_digits: %d, \t n_samples %d, \t n_features %d"
      % (n_digits, n_samples, n_features))


print(82 * '_')
print('init\t\ttime\tinertia\thomo\tcompl\tv-meas\tARI\tAMI\tsilhouette')


def bench_k_means(estimator, name, data):
    t0 = time()
    estimator.fit(data)
    print('%-9s\t%.2fs\t%i\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f\t%.3f'
          % (name, (time() - t0), estimator.inertia_,
             metrics.homogeneity_score(labels, estimator.labels_),
             metrics.completeness_score(labels, estimator.labels_),
             metrics.v_measure_score(labels, estimator.labels_),
             metrics.adjusted_rand_score(labels, estimator.labels_),
             metrics.adjusted_mutual_info_score(labels,  estimator.labels_),
             metrics.silhouette_score(data, estimator.labels_,
                                      metric='euclidean',
                                      sample_size=sample_size)))

bench_k_means(KMeans(init='k-means++', n_clusters=n_digits, n_init=10),
              name="k-means++", data=data)

bench_k_means(KMeans(init='random', n_clusters=n_digits, n_init=10),
              name="random", data=data)

# in this case the seeding of the centers is deterministic, hence we run the
# kmeans algorithm only once with n_init=1
pca = PCA(n_components=n_digits).fit(data)
bench_k_means(KMeans(init=pca.components_, n_clusters=n_digits, n_init=1),
              name="PCA-based",
              data=data)
print(82 * '_')

# ######
# Visualize the results on PCA-reduced data

reduced_data = PCA(n_components=2).fit_transform(data)
kmeans = KMeans(init='k-means++', n_clusters=n_digits, n_init=10)
kmeans.fit(reduced_data)

# Step size of the mesh. Decrease to increase the quality of the VQ.
h = .02     # point in the mesh [x_min, x_max]x[y_min, y_max].

# Plot the decision boundary. For that, we will assign a color to each
x_min, x_max = reduced_data[:, 0].min() - 1, reduced_data[:, 0].max() + 1
y_min, y_max = reduced_data[:, 1].min() - 1, reduced_data[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))

# Obtain labels for each point in mesh. Use last trained model.
Z = kmeans.predict(np.c_[xx.ravel(), yy.ravel()])

# Put the result into a color plot
Z = Z.reshape(xx.shape)
plt.figure(1)
plt.clf()
plt.imshow(Z, interpolation='nearest',
           extent=(xx.min(), xx.max(), yy.min(), yy.max()),
           cmap=plt.cm.Paired,
           aspect='auto', origin='lower')

plt.plot(reduced_data[:, 0], reduced_data[:, 1], 'k.', markersize=2)
# Plot the centroids as a white X
centroids = kmeans.cluster_centers_
plt.scatter(centroids[:, 0], centroids[:, 1],
            marker='x', s=169, linewidths=3,
            color='w', zorder=10)
plt.title('K-means clustering on the digits dataset (PCA-reduced data)\n'
          'Centroids are marked with white cross')
plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.xticks(())
plt.yticks(())
plt.show()
################################################

############################# CLASSIFICATION ############################# 

#Separation de la base par la fonction train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.8,
                                                    random_state=0)


print("Nb d'échantillons d'apprentissage (train) :  {}".format(X_train.shape[0]))
print("Nb d'échantillons de validation (test):    {}".format(X_test.shape[0]))


#######  svm avec gridSearch #########
#svm avec gridSearch 
parameters_svm =[{'kernel': ['rbf'], 'gamma': [1e-2 ,1e-3, 1e-4,1e-5],
                     'C': [1, 10, 100, 120]},
                    {'kernel': ['linear'], 'C': [1, 10, 100, 120]}]


SVM_grid = svm.SVC()

def recherche(classifier,parameters):
    
    clf = GridSearchCV(classifier, parameters, scoring = 'f1_macro', cv = 5 )
    clf.fit(X_train, y_train)
    gridsearch_result = pd.DataFrame(clf.cv_results_["params"])
    gridsearch_result["score"] = clf.cv_results_["mean_test_score"]
    clf_final = clf.best_estimator_
    print(clf_final.set_params)
    print("Score base train : ",clf_final.score(X_train,y_train)*100, "%")
    print("Score base test : ",clf_final.score(X_test,y_test)*100,"%")
    return gridsearch_result, clf_final

grid_svm ,clf_SVM_GRID= recherche(SVM_grid,parameters_svm)
#graphique
grid_svm[["C","gamma","score"]].groupby(["C","gamma"]).mean().unstack().plot()


####### MLP avec GridSearch  #######

# Liste des classifieurs évalués
paramMLP_grid = {'solver': ['lbfgs','adam'], 
              'max_iter': [1000,1100],
              'alpha': 10.0 ** -np.arange(1, 4), #prend 4 valeurs comme 10^(-1),10^(-2)
              'hidden_layer_sizes':np.arange(10, 12),
              'activation':['tanh', 'relu']}
MLP = MLPClassifier()
grid_MLP ,clf_MLP= recherche(MLP,paramMLP_grid)
grid_MLP[["alpha","hidden_layer_sizes","score"]].groupby(["hidden_layer_sizes","alpha"]).mean().unstack().plot()


####### MLP avec Random Forest  #######
n_estimators = [80,100,150,200,400]
max_depth = [5, 10, 20, 30, 50]

parameters_rf = {'n_estimators': n_estimators ,
              'max_depth' : max_depth
             }
RF = RandomForestClassifier()
grid_RF ,clf_RF= recherche(RF,parameters_rf)
grid_RF[["n_estimators","max_depth","score"]].groupby(["n_estimators","max_depth"]).mean().unstack().plot()


####### Decision tree  #######


clf_decisiontree = DecisionTreeClassifier(
                             class_weight = "balanced",
                             criterion='gini', random_state=0)

clf_decisiontree.fit(X_train, y_train)
print("Train F1-score : {}".format(
    f1_score(y_train, clf_decisiontree.predict(X_train), average='macro')
))
 
print("Valid F1-score : {}".format(
    f1_score(y_test, clf_decisiontree.predict(X_test), average='macro')
))






######### Gradient Boosting #####
clf_gradient = GradientBoostingClassifier(n_estimators=200, learning_rate=1.0, max_depth=4, random_state=0)
clf_gradient.fit(X_train, y_train)

print("Train F1-score : {}".format(
    f1_score(y_train, clf_gradient.predict(X_train), average='macro')
))
 
print("Valid F1-score : {}".format(
    f1_score(y_test, clf_gradient.predict(X_test), average='macro')
))

clf_gradient.score(X_train, y_train)
clf_gradient.score(X_test, y_test)




# Chargement d'une autre méthode de classification (KNN)
from sklearn.neighbors import KNeighborsClassifier

# Liste des classifieurs evalues
classifiers = [('KNN_k=1', KNeighborsClassifier(n_neighbors=1)),
               ('Gradient_boost', clf_gradient),
               ('Decision_tree',clf_decisiontree),
               ('SVM_Grid_search',clf_SVM_GRID),
               ('SVM_OVO',svm.SVC(decision_function_shape='ovo')),
               ('MLP_grid',MLPClassifier(alpha=0.001, hidden_layer_sizes=11, max_iter=1000)),
               ('Rand_forest', RandomForestClassifier(max_depth=30, n_estimators=400))
              ]


# Definition des metrique de performance
# w/ validation croisee
def perf_compute(x_train,y_train,x_test,y_test,clf, name, loops=10):
    """
    Calcule le temps d'apprentissage, de prediction, le score
    et la matrice de confusion d'un classifieur
    """
    # On initialise le conteneur
    perf = pd.Series(name=name,dtype=pd.StringDtype())
    # On crée les callables qu'on passera à la fonction de profiling
    fit = lambda: clf.fit(x_train, y_train)
    score_train = lambda: clf.score(x_train, y_train)
    score_test = lambda: clf.score(x_test, y_test)
    score_val_cross_train = cross_val_score(clf,x_train,y_train,cv=5)

    # On profile le temps des phases d'entrainement et de prédiction en ms
    perf['train_tps'] = timeit(fit, number=loops) / loops * 1000
    perf['test_tps'] = timeit(score_test, number=loops) / loops * 1000
    perf['total_tps'] = perf.train_tps + perf.test_tps
    # On calcule le score en pourcentage
    perf['score_test'] = fit().score(x_test, y_test) * 100
    # On calcule le score en pourcentage
    perf['score_train'] = fit().score(x_train, y_train) * 100
    # On calcule la matrice de confusion
    perf['conf_mat'] = [confusion_matrix(fit().predict(x_test), y_test)]
    # Normalisation par ligne de la matrice de confusion  pour avoir des pourcentages d'erreurs.
    # cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    perf['cross_val_train'] = score_val_cross_train.mean()*100

    return perf




# On lance le calcule de performance. On profile en bouclant 100 fois
perfs = pd.DataFrame([perf_compute(X_train, y_train, X_test, y_test,clf, name) for name, clf in classifiers])
perfs = perfs.sort_values(by='score_test')#trie par rapport au score train 

perfs['train_tps test_tps total_tps score_test score_train cross_val_train'.split()].T


#fonction pour la matrice de confusion
def plot_conf_mat(perf, ax, title='Model'):
    """
    Affichage de la matrice de confusion
    """
    sns.heatmap(perf.conf_mat[0], ax=ax, square=True, annot=True)
    ax.set_title('{}: {}\nScore: {:.2f}'.format(title, perf.name, perf.score_test))
    ax.set_xlabel('True label')
    ax.set_ylabel('Predicted label')

# Affichage du plus mauvais et du meilleur classifieur
# Les classifieurs sont classés par scores croissant
fig, axs = plt.subplots(ncols=2, figsize=(12, 4))
plot_conf_mat(perfs.iloc[0], ax=axs[0], title='Pire model')
plot_conf_mat(perfs.iloc[-1], ax=axs[1], title='Meilleur model')

#Sortie des observation mal prédite avec 
predicted = clf_decisiontree.predict(X_test)
expected = y_test

# Plot the prediction
fig = plt.figure(figsize=(6, 6))  # figure size in inches
fig.subplots_adjust(left=0, right=1, bottom=0, top=1, hspace=0.05, wspace=0.05)

# plot the digits: each image is 8x8 pixels
for i in range(64):
    if predicted[i] != expected[i]:
        ax.text(0, 7, str(predicted[i]), color='red')
        ax = fig.add_subplot(8, 8, i +1, xticks=[], yticks=[])
        ax.imshow(X_test.reshape(-1, 8, 8)[i], cmap=plt.cm.binary,
                  interpolation='nearest')


################## CNN ##################
#importation de la base
        
#représentation des différents filtre afin de mieux comprendre son enjeux 
(x_train, y_train), (x_test, y_test) = mnist.load_data()

batch_size = 128
nb_classes = 10
nb_epoch = 6

# input image dimensions
img_rows, img_cols = 28, 28
# number of convolutional filters to use
nb_filters = 32
# size of pooling area for max pooling
pool_size = (2, 2)
# convolution kernel size
kernel_size = (3, 3)

if K.image_data_format() == 'channels_first':
    x_train = x_train.reshape(x_train.shape[0], 1, img_rows, img_cols)
    x_test = x_test.reshape(x_test.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
    x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

#sub-sample of test data to improve training speed. Comment out
#if you want to train on full dataset.
x_train = x_train[:20000,:,:,:]
y_train = y_train[:20000]

#normalise the images and double check the shape and size of the image data
x_train = x_train.astype('float32')
x_test = x_test.astype('float32')
x_train /= 255
x_test /= 255

# convert class vectors to binary class matrices
y_test_inds = y_test.copy()
y_train_inds = y_train.copy()
y_train = keras.utils.to_categorical(y_train, nb_classes)
y_test = keras.utils.to_categorical(y_test, nb_classes)
num_classes = y_test.shape[1]
#Create new sequential model, same as before but just keep the convolutional layer.
model_new = Sequential()
model_new.add(Conv2D(nb_filters, kernel_size=(3, 3),
                 activation='relu',
                 input_shape=input_shape))

def sorti_image(model,nb_filters):
    #set weights for new model from weights trained on MNIST.
    for i in range(1):
        model.layers[i].set_weights(model.layers[i].get_weights())
    
    #pick a random digit and "predict" on this digit (output will be first layer of CNN)
    i = np.random.randint(0,len(x_test))
    digit = x_test[i].reshape(1,28,28,1)
    pred = model.predict(digit)
    print("Chiffre : ", y_test_inds[i])

    #For all the filters, plot the output of the input
    plt.figure(figsize=(18,18))
    filts = pred[0]
    for i in range(nb_filters):
        filter_digit = filts[:,:,i]
        plt.subplot(6,6,i+1)
        plt.imshow(filter_digit,cmap='gray'); plt.axis('off');

def medium_model1():
    # create model
    model = Sequential()
    model.add(Conv2D(32, kernel_size=(5, 5), input_shape=input_shape, activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    return model

def large_model2():
    # create model
    model = Sequential()
    model.add(Conv2D(30, kernel_size=(5, 5), input_shape=input_shape, activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(15, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    return model

#sorti_image(medium_model(), X_testCNN, 32)
model = medium_model1()
sorti_image(model,nb_filters)
sorti_image(large_model2(),15)


################## CNN ##################
#importation de la base
img_rows, img_cols = 28, 28
input_shape = (img_rows, img_cols,1)


MNIST = tf.keras.datasets.mnist

(X_train1, y_train1), (X_test1, y_test1) = MNIST.load_data()

# ##################base kaggle ##################
# Pour la prédiction de la base kaggle
kaggle_Xtest_final = X1test
kaggle_Xtest_final = kaggle_Xtest_final/255.0
kaggle_Xtest_final = kaggle_Xtest_final.values.reshape(kaggle_Xtest_final.shape[0], img_rows, img_cols, 1)

# ####################################


#reformation de la base MNIST
X_train1 = X_train1/255.0
X_test1 = X_test1/255.0

y_train1 = to_categorical(y_train1)
y_test1 = to_categorical(y_test1)



X_train1 = np.delete(X_train1, [range(56000)], 0)
X_test1 = np.delete(X_test1, [range(9000)], 0)



y_train1 = np.delete(y_train1, [range(56000)], 0)
y_test1 = np.delete(y_test1, [range(9000)], 0)


#creation d'une fonction dd'un graphique LOSS et ACCURACY
def plot_history_loss_and_acc(history_keras_nn):

    fig, axs = plt.subplots(1,2, figsize=(12,4))

    axs[0].plot(history_keras_nn.history['loss'])
    axs[0].plot(history_keras_nn.history['val_loss'])
    axs[0].set_title('model loss')
    axs[0].set_ylabel('loss')
    axs[0].set_xlabel('epoch')
    axs[0].legend(['train', 'validation'], loc='upper left')

    axs[1].plot(history_keras_nn.history['accuracy'])
    axs[1].plot(history_keras_nn.history['val_accuracy'])
    axs[1].set_title('model accuracy')
    axs[1].set_ylabel('accuracy')
    axs[1].set_xlabel('epoch')
    axs[1].legend(['train', 'validation'], loc='upper left')

    plt.show()
    

X_trainCNN = X_train1.reshape(X_train1.shape[0],img_rows, img_cols, 1)
X_testCNN = X_test1.reshape(X_test1.shape[0], img_rows, img_cols, 1)

num_classe = 10 # numero de classe à prédire 0 à 9

batchsize = 100
def small_model():
    
    model = Sequential()
    
    model.add(Conv2D(64, kernel_size=(3, 3), activation= 'relu', input_shape=input_shape))
    model.add(Conv2D(32, (3, 3), activation='relu'))
    model.add(Flatten())
    model.add(Dense(10, activation='softmax'))
    model.compile(loss=categorical_crossentropy, optimizer=Adadelta(), metrics=['accuracy'])

    return model

def medium_model():
    # create model
    model = Sequential()
    model.add(Conv2D(32, kernel_size=(5, 5), input_shape=input_shape, activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    mod
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dense(10, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

def large_model(drop):
    # create model
    model = Sequential()
    model.add(Conv2D(30, kernel_size=(5, 5), input_shape=input_shape, activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(15, (3, 3), activation='relu'))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Dropout(drop))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dense(50, activation='relu'))
    model.add(Dense(10, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model


# Matrice de confusion en heatmap
def plot_confusion_matrix(cm, classes, title='Confusion matrix', cmap=plt.cm.Blues):
    cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    plt.figure(figsize=(10,10))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()

def model_CNN(model, list_acc):
    modeCNN = model
    history_cnn = modeCNN.fit(X_trainCNN, y_train1, validation_data=(X_testCNN,y_test1),epochs=10, batch_size=batchsize, verbose = 1)
    acc = history_cnn.history['accuracy']
    list_acc.append(acc)
    plot_history_loss_and_acc(history_cnn)
    y_pred = modeCNN.predict_classes(X_testCNN)
    y_pred = to_categorical(y_pred)
    matrice_confusion = confusion_matrix(y_test1.argmax(axis=1), y_pred.argmax(axis=1))
    print("Matrice de confusion : ",confusion_matrix(y_test1.argmax(axis=1), y_pred.argmax(axis=1)))
    print("Accuracy score sur Y_test : ",accuracy_score(y_test1.argmax(axis=1), y_pred.argmax(axis=1))*100,"%")
    classe = [0,1,2,3,4,5,6,7,8,9]
    # plot normalized confusion matrix
    plt.figure()
    plot_confusion_matrix(matrice_confusion,classe, title='Normalized confusion matrix')
    plt.show()
    return history_cnn
    

list_acc_small = []
list_acc_medium = []
list_acc_large = []


model_CNN(small_model, list_acc_small)
model_CNN(medium_model, list_acc_medium)

model_largeCNN =large_model(0.2)
model_CNN(model_largeCNN, list_acc_large)

#Permet de voir quel probabilite (0 à 1) est le plus optimum 
list_drop = [0.25,0.3,0.4, 0.5,0.6, 0.75,0.85]
list_acc = []
for drop in list_drop:
    modeCNN = large_model(drop)
    history_cnn_1 = modeCNN.fit(X_trainCNN, y_train1, validation_data=(X_testCNN,y_test1),epochs=10, batch_size=batchsize, verbose = 1)
    acc = history_cnn_1.history['accuracy']
    list_acc.append(acc)



x = list_drop
y = list_acc
plot(x, y)
plt.title("Graphique prob. Dropout et accuracy")
xlabel("Prob. Dropout")
ylabel("Accuracy")

show()

#######enregistrement du Large model et importation######
# model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

hist_large
# This function saves a model on the drive using two files : a json and an h5
def save_keras_model(model, filename):
    # serialize model to JSON
    model_json = model.to_json()
    with open(filename+".json", "w") as json_file:
        json_file.write(model_json)
    # serialize weights to HDF5
    model.save_weights(filename+".h5")
    
# This function loads a model from two files : a json and a h5
# BE CAREFUL : the model NEEDS TO BE COMPILED before any use !
def load_keras_model(filename):
    # load json and create model
    json_file = open(filename+".json", 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    # load weights into new model
    loaded_model.load_weights(filename+".h5")
    return loaded_model
    
save_keras_model(large_model(0.2), "large_model_save")

from keras.models import model_from_json
large_model_save1 = load_keras_model("large_model_save")
large_model_save1.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
######################################################


#Prediction avec les donnees de Kaggle
#retéléchargement de la base
################## CNN ##################
#importation de la base

MNIST = tf.keras.datasets.mnist

(X_train1, y_train1), (X_test1, y_test1) = MNIST.load_data()

#reformation de la base MNIST
X_train1 = X_train1/255.0
X_test1 = X_test1/255.0

y_train1 = to_categorical(y_train1)
y_test1 = to_categorical(y_test1)

X_trainCNN = X_train1.reshape(X_train1.shape[0],img_rows, img_cols, 1)
X_testCNN = X_test1.reshape(X_test1.shape[0], img_rows, img_cols, 1)

num_classe = 10 # numero de classe à prédire 0 à 9

batchsize = 200

large_model_save1.fit(
   x=X_trainCNN,
   y=y_train1,
   epochs=10,
   batch_size=200,
   shuffle=True
)
eval = large_model_save1.evaluate(X_testCNN, y_test1)


predictions1 = large_model_save1.predict(kaggle_Xtest_final)
print("Nombre prédit par le modele retenu : ",np.argmax(predictions1[250]))
imgplot = plt.imshow(kaggle_Xtest_final[250].reshape(28, 28))

print("Nombre prédit par le modele retenu : ",np.argmax(predictions1[500]))
imgplot = plt.imshow(kaggle_Xtest_final[500].reshape(28, 28))



df = pd.DataFrame(predictions1)
path_save_csv = "/soumission.txt"
df.to_csv(path_save_csv)


